﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFN563_Assignment
{
  
    /// controller controls the logic of game
   
    public class Controller
    {
       
        public Board PlayAgainPrompt()
        {
            Board board = null;

            Console.WriteLine("Do you want to play again?  Press Y to play again N to finish the game");
            if (Console.ReadLine().ToUpper().StartsWith("Y"))
            {
                board = new Board();
                //print board
                Console.WriteLine(board.ToString());
            }

            return board;
        }


        /// check win condition
  

        public bool WinCondition(Board board, int currentplayerSymbol)
        {
            bool win_vertical = false;
            bool win_horizontal = false;
            bool win_digo1 = false;
            bool win_digo2 = false;
            bool win = false;

            for (int i = 0; i < Board.ROWS; i++)
            {
                for (int j = 0; j < Board.COLUMNS - 3; j++)


                {
                    if (

                        board.board[i, j] == currentplayerSymbol && board.board[i, j + 1] == currentplayerSymbol &&
                        board.board[i, j + 2] == currentplayerSymbol && board.board[i, j + 3] == currentplayerSymbol
                        )
                    {

                        Console.WriteLine(" \n\n Horizontal Connect 4  ");
                        win_horizontal = true;

                    }
                }


            }


            for (int i = 0; i < Board.ROWS - 3; i++)
            {
                for (int j = 0; j < Board.COLUMNS; j++)
                {

                    if (

                        board.board[i, j] == currentplayerSymbol && board.board[i + 1, j] == currentplayerSymbol &&
                        board.board[i + 2, j] == currentplayerSymbol && board.board[i + 3, j] == currentplayerSymbol
                        )
                    {

                        Console.WriteLine(" \n\n Vertical Connect 4  ");
                        win_horizontal = true;

                    }




                }


            }

            for (int i = 0; i < Board.ROWS - 3; i++)
            {
                for (int j = 0; j < Board.COLUMNS - 3; j++)
                {

                    if (

                        board.board[i, j] == currentplayerSymbol && board.board[i + 1, j + 1] == currentplayerSymbol &&
                        board.board[i + 2, j + 2] == currentplayerSymbol && board.board[i + 3, j + 3] == currentplayerSymbol
                        )
                    {

                        Console.WriteLine(" \n\n Uppder Digonal Connect 4  ");
                        win_digo1 = true;

                    }
                }
            }

            for (int i = 6; i > 3; i--)
            {
                for (int j = 0; j < 3; j++)
                {


                    if (
                         board.board[i, j] == currentplayerSymbol && board.board[i - 1, j + 1] == currentplayerSymbol &&
                         board.board[i - 2, j + 2] == currentplayerSymbol && board.board[i - 3, j + 3] == currentplayerSymbol
                        )

                    {

                        Console.WriteLine(" \n\n Uppder Digonal Connect 4  ");
                        win_digo2 = true;

                    }
                }
            }

            if (win_vertical || win_horizontal || win_digo1 || win_digo2)
            {
                win = true;
            }

            return win;
        }


        /// place in column
 
        public void PlaceInColumn(Board board, int columnNumber, int symbol)
        {
            int index = Board.ROWS - 1;  // index = 0 is the top 
            int cc = board.board[index, columnNumber];
            while ((cc == 1 || cc == 2) && index >= 0)
            {
                index--;
                if (index >= 0) cc = board.board[index, columnNumber];
            }

            if (index < 0) board.columnFull[columnNumber] = true;

            if (!board.columnFull[columnNumber])
            {
                board.board[index, columnNumber] = symbol;
                //print board
                Console.WriteLine(board.ToString());
            }
            else
            {
                Console.WriteLine(" The column is full please try again. ");
            }
        }

    }
}
