﻿using System;
namespace connect4
{
    public class SaveRepository
    {
        public SaveRepository()
        {
        }
    }
}
