﻿using System;
namespace connect4
{
    public class UserInterface
    {
        public UserInterface()
        {
        }
    }
}
