import React from 'react'
import styled from 'styled-components';
import Card from 'react-bootstrap/Card'

const GridWrapper = styled.div`
  display: grid;
  grid-gap: 10px;
  margin-top: 1em;
  margin-left: 10em;
  margin-right: 10em;

`;
function Home2() {


    return (
        <div>

            <GridWrapper>

                <di>
                    <h1>  Crypto Analyzer</h1>
                </di>

                <p>Welcom to <strong>Crypto Analyzer </strong></p>
                <p>You can check out new crypto news, information ,historical chart from this website</p>
            </GridWrapper>


            <GridWrapper>


                <Card style={{ width: '40rem' }}>


                    <Card.Body>
                        <Card.Title> <h1> Start Using Our Watchlist</h1></Card.Title>
                        <Card.Img variant="top" src="https://cdn.wccftech.com/wp-content/uploads/2022/05/16415655339687.jpg" />



                    </Card.Body>
                </Card>


            </GridWrapper>

            <GridWrapper>

                <img
                    src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh7rNU2MKQKdRo20gztQ5lpgZFKJS6wTtxXg&usqp=CAU'
                    className='img-thumbnail'
                    alt='...'
                    style={{ maxWidth: '22rem' }}
                />
                <p> Start finding crypto from click left sidebar  coin icon!</p>

            </GridWrapper>
        </div>
    )
}

export default Home2