import React from 'react';
import AddCoin from './AddCoin'
import CryptoList from './CryptoList'
import './Crypto.css'
function Crypto() {
  return (

    <>

      <div className='GridWrapper'>
        <h2> Crypto Analyzer</h2>
        <p>Select the crpyto currency you want to add.</p>
        <p> Click the added crypto currency to get detailed information</p>

      </div>

      <hr></hr>

      <div className='GridWrapper'>
        <AddCoin />
      </div>
      <hr></hr>
      <div className='GridWrapper'>
        <CryptoList />
      </div>

    </>
  )
}

export default Crypto