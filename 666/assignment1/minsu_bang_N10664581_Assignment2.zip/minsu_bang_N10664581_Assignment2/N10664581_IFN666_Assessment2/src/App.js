
import './App.css';
import * as React from 'react'
import Home from '../src/components/Home2'
import Crypto from './components/Crypto'
import About from './components/About'
import Detail from './components/Detail'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { NavigationBar } from './components/NavigationBar';

import Sidebar from './components/Sidebar';
import { WatchListProvider } from './components/watchList';

function App() {
  return (

    <React.Fragment>

      <WatchListProvider>
        <Router>
          <NavigationBar />
          <Sidebar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/cryptos" element={<Crypto />} />
            <Route path="/cryptos/:id" element={<Detail />} />
          </Routes>
        </Router>
      </WatchListProvider>
    </React.Fragment>

  );
}

export default App;
